class Assignment2{
	public static void main(String... s){
		System.out.println("Welcome "+s[0]);
	}
}