class Assignment3{
	public static void main(String... s){
		int argument1=Integer.parseInt(s[0]);
		int argument2=Integer.parseInt(s[1]);
		int sum=argument1+argument2;
		System.out.println("The sum of "+argument1+" and "+argument2+" is "+sum);
	}
}