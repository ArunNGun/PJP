class Assignment4{
	public static void main(String... s){
		
		int[] array={30,36,45,65,71,98};
		for(int i=0;i<array.length;i++){
			System.out.printf("%c ",array[i]);
		}

	}	
}