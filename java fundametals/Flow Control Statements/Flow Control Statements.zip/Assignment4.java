class Assignment4{
	public static void main(String... s){
	char character1='e';
	char character2='a';

		if(character1<character2)
			System.out.println(character1+","+character2);
		else
			System.out.println(character2+","+character1);
		
	}
}
